<h4 class="mt-5 pt-3 mb-3">Leave List</h4>
<div class="d-flex justify-content-between">
    <form action="/admin/filterDate" method="get">
        <label for="month">Month</label>
        <select name="month" id="month">
            <option value="all" <?php if(old('month')=='all' ): ?> selected="selected" <?php endif; ?>>All</option>
            <option value="1" <?php if(old('month')=='1' ): ?> selected="selected" <?php endif; ?>>January</option>
            <option value="2" <?php if(old('month')=='2' ): ?> selected="selected" <?php endif; ?>>February</option>
            <option value="3" <?php if(old('month')=='3' ): ?> selected="selected" <?php endif; ?>>March</option>
            <option value="4" <?php if(old('month')=='4' ): ?> selected="selected" <?php endif; ?>>April</option>
            <option value="5" <?php if(old('month')=='5' ): ?> selected="selected" <?php endif; ?>>Mei</option>
            <option value="6" <?php if(old('month')=='6' ): ?> selected="selected" <?php endif; ?>>June</option>
            <option value="7" <?php if(old('month')=='7' ): ?> selected="selected" <?php endif; ?>>July</option>
            <option value="8" <?php if(old('month')=='8' ): ?> selected="selected" <?php endif; ?>>August</option>
            <option value="9" <?php if(old('month')=='9' ): ?> selected="selected" <?php endif; ?>>September</option>
            <option value="10" <?php if(old('month')=='10' ): ?> selected="selected" <?php endif; ?>>October</option>
            <option value="11" <?php if(old('month')=='11' ): ?> selected="selected" <?php endif; ?>>November</option>
            <option value="12" <?php if(old('month')=='12' ): ?> selected="selected" <?php endif; ?>>December</option>
        </select>
        <label for="year">Year</label>
        <select name="year" id="year">
            <option value="all">All</option>
            <option value="2020">2020</option>
            <option value="2021">2021</option>
            <option value="2022">2022</option>
            <option value="2023">2023</option>
            <option value="2024">2024</option>
            <option value="2025">2025</option>
            <option value="2025">2025</option>
            <option value="2026">2026</option>
            <option value="2027">2027</option>
            <option value="2028">2028</option>
            <option value="2029">2029</option>
            <option value="2030">2030</option>
        </select>
        <button class="submit">Search</button>
        <a href="<?php echo e(Route('admin.leaveList.index')); ?>"><button type="button">Show All</button></a>
    </form>
    <a href="/admin/leaveListPrint"><button class="btn-sm btn-danger mr-1">Print PDF</button></a>
</div>

<?php if(session('status')): ?>
<div class="alert alert-success">
    <?php echo e(session('status')); ?>

</div>
<?php endif; ?>

<table class="table table-striped table-hover text-center table-shadow mt-2">
    <thead>
        <tr>
            <th scope="col">No</th>
            <th scope="col">Leave ID</th>
            <th scope="col">Name</th>
            <th scope="col">Start Date</th>
            <th scope="col">End Date</th>
            <th scope="col">Leave Taken</th>
            <th scope="col">Status</th>
            <th scope="col">Type of Leave</th>
            <th scope="col">Description</th>
        </tr>
    </thead>
    <tbody>
        <?php $i = $leaves->firstItem();?>
        <?php $__currentLoopData = $leaves; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leave): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th scope="row"><?php echo e($i); ?></th>
            <td><?php echo e($leave->leave_code); ?></td>
            <td><?php echo e($leave->employee->name); ?></td>
            <td><?php echo e(date_format(new DateTime($leave->start_date), 'd-m-Y')); ?></td>
            <td><?php echo e(date_format(new DateTime($leave->enddate), 'd-m-Y')); ?></td>
            <td><?php echo e($leave->leave_amount); ?></td>
            <?php if($leave->status == -1): ?>
            <td>Rejected</td>
            <?php elseif($leave->status == 1): ?>
            <td>Approved</td>
            <?php endif; ?>
            <td><?php echo e($leave->type_of_leave); ?></td>
            <td><?php echo e($leave->description); ?></td>
            </td>
        </tr>
        <?php $i++;?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php echo e($leaves->links()); ?>

<a href="<?php echo e(Route('admin.home')); ?>" class="text-white"><button type="button" class="btn btn-secondary">Back</button></a><?php /**PATH D:\xampp\htdocs\Paidleavy\resources\views/components/adminLeaveList.blade.php ENDPATH**/ ?>