

<?php $__env->startSection('content'); ?>
<br>
<h4>Add Department</h4>
<?php if(session('status')): ?>
<div class="alert alert-danger">
    <?php echo e(session('status')); ?>

</div>
<?php endif; ?>
<?php echo Form::open(['method'=>'POST','action'=>'DepartmentController@store','files'=>true]); ?>

<div class="card pt-3 ">
    <div class="form-group row offset-md-1">
        <?php echo Form::label('department_id', 'Department ID :', ['class'=>'col-sm-2 col-form-label']); ?>


        <?php $a = "D"; $b = rand(1000, 10000); $c = $a . $b; ?>
        <div class="col-sm-10">
            <?php echo Form::text('department_id', $c, ['class'=>'form-control w-50','readonly']); ?>

        </div>
    </div>
    <div class="form-group row offset-md-1">
        <?php echo Form::label('name', 'Name :', ['class'=>'col-sm-2 col-form-label']); ?>

        <div class="col-sm-10">
            <input type="text" name="name" id="name" class="form-control w-50 <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                placeholder="Department Name">
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class=" invalid-feedback">
                <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        </div>
    </div>
    <div class="form-group offset-md-1 offset-sm-1 mt-4 " style="margin-left:25%;">
        <?php echo Form::submit('Add', ['class'=>'btn btn-primary']); ?>

    </div>
</div>
<?php echo Form::close(); ?>

<br>
<a href="<?php echo e(Route('admin.department.index')); ?>"><button class="btn btn-secondary ">Back</button></a>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Paidleavy\resources\views/admin/department/create.blade.php ENDPATH**/ ?>