

<?php $__env->startSection('content'); ?>
<!-- Dashboard Admin here -->


<h3 class="mt-5 pt-3">Admin's Dashboard</h3>

<div class="container">
    <div class="row">
        <div class="col-lg-3 col-md-6 col-sm-6">
            <div class="card mt-5 admin-card">
                <div class="card-body card-content">
                    <div>
                        <h1><?php echo e($totalEmployee); ?></h1>
                        <h5 class="card-title">Employee</h5>
                    </div>
                    <i class="fa fa-users"></i>
                </div>

                <div class="card-footer">
                    <a href="<?php echo e(Route('admin.employee.index')); ?>" class="card-link">View More</a>
                </div>
            </div>
        </div>

        <div class="col-lg-3 col-md-6 col-sm-6">
            <div class="card mt-5 admin-card">
                <div class="card-body card-content">
                    <div>
                        <h1><?php echo e($totalDepartment); ?></h1>
                        <h5 class="card-title">Department</h5>
                    </div>
                    <i class="fas fa-building"></i>
                </div>
                <div class="card-footer">
                    <a href="<?php echo e(Route('admin.department.index')); ?>" class="card-link">View More</a>
                </div>
            </div>
        </div>

        <div class="col-lg-3 col-md-6 col-sm-6">
            <div class="card mt-5 admin-card">
                <div class="card-body card-content">
                    <div>
                        <h1><?php echo e($totalLeave); ?></h1>
                        <h5 class="card-title">Leave List</h5>
                    </div>
                    <i class="bx bx-list-ul"></i>
                </div>

                <div class="card-footer">
                    <a href="<?php echo e(Route('admin.leaveList.index')); ?>" class="card-link">View More</a>
                </div>
            </div>
        </div>

        <div class="col-lg-3 col-md-6 col-sm-6">
            <div class="card mt-5 admin-card">
                <div class="card-body card-content">
                    <div>
                        <h1><?php echo e($totalPendingLeave); ?></h1>
                        <h5 class="card-title">Pending Leave</h5>
                    </div>
                    <i class='bx bxs-time-five'></i>
                </div>

                <div class="card-footer">
                    <a href="<?php echo e(Route('admin.pendingLeave.index')); ?>" class="card-link">View More</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Table Karyawan -->

    <h4 class="mt-5 pt-3 mb-3">Employee Data List</h4>
    <table class="table table-striped table-hover text-center table-shadow">
        <thead>
            <tr>
                <th scope="col">No</th>
                <th scope="col">Employee ID</th>
                <th scope="col">Name</th>
                <th scope="col">Department</th>
                <th scope="col">Position</th>
                <th scope="col">Status</th>
                <th scope="col">Leave Balance</th>
            </tr>
        </thead>
        <tbody>
            <?php $i = $employees->firstItem();?>
            <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <tr>
                <th scope="row"><?php echo e($i); ?></th>
                <td><?php echo e($employee->employee_id); ?></td>
                <td><?php echo e($employee->name); ?></td>
                <td><?php echo e($employee->department); ?></td>
                <td><?php echo e($employee->position); ?></td>
                <td><?php echo e($employee->status); ?></td>
                <td><?php echo e($employee->leave_balance); ?></td>
            </tr>
            <?php $i++;?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php echo e($employees->links()); ?>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Paidleavy\resources\views/admin/home.blade.php ENDPATH**/ ?>