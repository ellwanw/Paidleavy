

<?php $__env->startSection('content'); ?>
<h4 class="mt-5 pt-3 mb-3">Leave History</h4>
<?php if(session('status')): ?>
<div class="alert alert-success">
    <?php echo e(session('status')); ?>

</div>
<?php endif; ?>

<table class="table table-striped table-hover text-center table-shadow">
    <thead>
        <tr>
            <th scope="col">No</th>
            <th scope="col">Leave ID</th>
            <th scope="col">Submission Date</th>
            <th scope="col">Start Date</th>
            <th scope="col">End Date</th>
            <th scope="col">Status</th>
            <th scope="col">Approver/Rejecter</th>
            <th scope="col">Approved/Rejected Date</th>
            <th scope="col">Action</th>
        </tr>
    </thead>
    <tbody>
        <?php $i = $leaves->firstItem();?>
        <?php $__currentLoopData = $leaves; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leave): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th scope="row"><?php echo e($i); ?></th>
            <td><?php echo e($leave->leave_code); ?></td>
            <td><?php echo e(date_format(new DateTime($leave->submit_date), 'd-m-Y')); ?></td>
            <td><?php echo e(date_format(new DateTime($leave->start_date), 'd-m-Y')); ?></td>
            <td><?php echo e(date_format(new DateTime($leave->end_date), 'd-m-Y')); ?></td>
            <?php if($leave->status == -1): ?>
            <td>Rejected</td>
            <?php elseif($leave->status == 1): ?>
            <td>Approved</td>
            <?php endif; ?>
            <td><?php echo e($leave->approver); ?></td>
            <td><?php echo e($leave->approved_date); ?></td>
            <td><a href="pendingLeave/<?php echo e($leave->id); ?>/edit" class="text-white"><button type="button"
                        class="btn btn-primary" type="button">
                        <i class="bx bx-search-alt bx-xs"></i>
                    </button></a>
            </td>
        </tr>
        <?php $i++; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<div class="d-flex justify-content-center">
    <?php echo e($leaves->links()); ?>

</div>
<a href="<?php echo e(Route('user.home')); ?>" class="text-white"><button type="button" class="btn btn-secondary">Back</button></a>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Paidleavy\resources\views/user/historyLeave/index.blade.php ENDPATH**/ ?>