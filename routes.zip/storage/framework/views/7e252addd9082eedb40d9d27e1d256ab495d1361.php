

<?php $__env->startSection('content'); ?>
<br>
<h4>Form Print PDF</h4>

<?php echo Form::open(['method'=>'GET','action'=>'LeaveController@createPDF','files'=>true]); ?>

<div class="card pt-3 ">
    <div class="form-group row offset-md-1">
        <?php echo Form::label('start_date', 'Start Date :', ['class'=>'col-sm-2 col-form-label']); ?>


        <div class="col-sm-10">
            <?php echo Form::date('start_date',null, ['class'=>'form-control w-50']); ?>

        </div>
    </div>
    <div class="form-group row offset-md-1">
        <?php echo Form::label('end_date', 'End Date :', ['class'=>'col-sm-2 col-form-label']); ?>

        <div class="col-sm-10">
            <?php echo Form::date('end_date',null, ['class'=>'form-control w-50']); ?>

        </div>
    </div>
    <div class="form-group offset-md-1 offset-sm-1 mt-4 " style="margin-left:25%;">
        <button type="submit" class="btn btn-danger"><i class='bx bx-printer'></i> Print</button>
    </div>
</div>
<?php echo Form::close(); ?>

<br>
<a href="<?php echo e(Route('admin.department.index')); ?>"><button class="btn btn-secondary ">Back</button></a>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Paidleavy\resources\views/admin/leaveList/create.blade.php ENDPATH**/ ?>