

<?php $__env->startSection('content'); ?>
<h4 class="mt-5 pt-3 mb-3">Employee Data List</h4>
<table class="table table-striped table-hover table-karyawan">
    <thead>
        <tr>
            <th scope="col">No</th>
            <th scope="col">Employee ID</th>
            <th scope="col">Name</th>
            <th scope="col">Department</th>
            <th scope="col">Position</th>
            <th scope="col">Status</th>
            <th scope="col">Leave Balance</th>
            <th scope="col">Action</th>
        </tr>
    </thead>
    <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


    <tr>
        <th scope="row"><?php echo e($loop->iteration); ?></th>
        <td><?php echo e($employee->employee_id); ?></td>
        <td><?php echo e($employee->name); ?></td>
        <td><?php echo e($employee->department); ?></td>
        <td><?php echo e($employee->position); ?></td>
        <td><?php echo e($employee->status); ?></td>
        <td><?php echo e($employee->leave_balance); ?></td>
        <td>
            <button type="button" class="btn btn-primary" type="button">
                <a href="/admin/employee/<?php echo e($employee->id); ?>" class="text-white"><i
                        class="bx bx-search-alt bx-xs"></i></a>
            </button>
        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<!-- User Profile Modal -->
<div class="modal user-profile__modal fade" id="my-profile" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                <h5 class="modal-title  text-white" id="my-profile">
                    My Profile
                </h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="card">
                    User Profile Data Here
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">
                    Back
                </button>
                <button type="button" class="btn btn-primary">
                    Save changes
                </button>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Paidleavy\resources\views/admin/employee.blade.php ENDPATH**/ ?>