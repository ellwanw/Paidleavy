
<?php $__env->startSection('content'); ?>
<h4 class="mt-5 pt-3 mb-3">Form Approval Cuti</h4>

<?php echo Form::open(['method'=>'PATCH','action'=>['LeaveController@updatePending',$leave->id],'files'=>true]); ?>


<input type="hidden" name="tanggalkeputusan" value="<?= date('d-m-Y'); ?>">

<div class="card pt-3 mb-5">
    <div class="form-row">
        <div class="form-group offset-md-1 offset-sm-1 w-25  col-md-4 col-sm-4">
            <?php echo Form::label('approver', 'Approver'); ?>

            <input type="text" name="approver" id="approver" placeholder="Approver"
                class="form-control <?php $__errorArgs = ['approver'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('approver')); ?>">
            <?php $__errorArgs = ['approver'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class=" invalid-feedback">
                <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        </div>

        <div class="form-group ml-3 w-25 col-md-4 col-sm-4">
            <?php echo Form::label('type_of_leave', 'Type of Leave'); ?>

            <?php echo Form::text('type_of_leave', $leave->type_of_leave, ['class'=>'form-control','readonly']); ?>

        </div>
    </div>

    <div class="form-row">
        <div class="form-group offset-md-1 offset-sm-1 w-25  col-md-4 col-sm-4">
            <?php echo Form::label('submit_date', 'Submission Date'); ?>

            <?php echo Form::text('submit_date', date_format(new DateTime($leave->submit_date), 'd-m-Y'),
            ['class'=>'form-control','readonly']); ?>

        </div>

        <div class="form-group ml-3 w-25 col-md-4 col-sm-4">
            <?php echo Form::label('description', 'Description'); ?>

            <?php echo Form::text('description', $leave->description, ['class'=>'form-control','readonly']); ?>

        </div>
    </div>

    <div class="form-row">
        <div class="form-group offset-md-1 offset-sm-1 col-md-4 col-sm-4 ">
            <?php echo Form::label('name', 'Name'); ?>

            <?php echo Form::text('name', $leave->employee->name, ['class'=>'form-control','readonly']); ?>

        </div>
        <div class="form-group ml-3 col-md-2 col-sm-1 ">
            <?php echo Form::label('leave_balance', 'Balance'); ?>

            <?php echo Form::text('leave_balance', $leave->employee->leave_balance, ['class'=>'form-control','readonly']); ?>

        </div>
        <div class="form-group col-md-2 col-sm-1">
            <?php echo Form::label('leave_amount', 'Amount'); ?>

            <?php echo Form::text('leave_amount', $leave->leave_amount, ['class'=>'form-control','readonly']); ?>

        </div>
    </div>

    <div class="form-row">
        <div class="form-group offset-md-1 offset-sm-1 col-md-4 col-sm-4 ">
            <?php echo Form::label('employee_id', 'Employee ID'); ?>

            <?php echo Form::text('employee_id', $leave->employee->employee_id, ['class'=>'form-control','readonly']); ?>

        </div>
        <div class="form-group ml-3 col-md-2 col-sm-1 ">
            <?php echo Form::label('start_date', 'Start Date'); ?>

            <?php echo Form::text('start_date', date_format(new DateTime($leave->start_date), 'd-m-Y'),
            ['class'=>'form-control','readonly']); ?>

        </div>
        <div class="form-group col-md-2 col-sm-1">
            <?php echo Form::label('end_date', 'End Date'); ?>

            <?php echo Form::text('end_date', date_format(new DateTime($leave->end_date), 'd-m-Y'),
            ['class'=>'form-control','readonly']); ?>

        </div>
    </div>

    <div class="form-row">
        <div class="form-group offset-md-1 offset-sm-1 col-md-4 col-sm-4">
            <?php echo Form::label('department', 'Department'); ?>

            <?php echo Form::text('department', $leave->employee->department, ['class'=>'form-control','readonly']); ?>

        </div>

        <div class="form-group ml-3 col-md-4 col-sm-4">
            <?php echo Form::label('phone', 'Phone'); ?>

            <?php echo Form::text('phone', $leave->phone, ['class'=>'form-control','readonly']); ?>

        </div>
    </div>

    <div class="form-row">
        <div class="form-group offset-md-1 offset-sm-1 col-md-4 col-sm-4">
            <?php echo Form::label('position', 'Position'); ?>

            <?php echo Form::text('position', $leave->employee->position, ['class'=>'form-control','readonly']); ?>

        </div>

        <div class="form-group mt-4 ml-3">
            <?php echo Form::radio('status', '+1',true ); ?> Approve
            <?php echo Form::radio('status', '-1',true,['class'=>'ml-3 mt-3']); ?> Reject

        </div>
    </div>

    <div class="form-group offset-md-1 offset-sm-1 mt-3 mb-5">
        <?php echo Form::submit('Submit', ['class'=>'btn btn-primary']); ?>

        <a href="<?php echo e(Route('admin.pendingLeave.index')); ?>"><button type="button"
                class="btn btn-secondary">Back</button></a>
    </div>

</div>

</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Paidleavy\resources\views/admin/pendingLeave/edit.blade.php ENDPATH**/ ?>