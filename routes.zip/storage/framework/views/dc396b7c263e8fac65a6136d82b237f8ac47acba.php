
<?php $__env->startSection('content'); ?>

<h4 class="mt-5 pt-3 mb-3">Leave Application Edit Form</h4>


<?php echo Form::open(['method'=>'PATCH','action'=>['LeaveController@update',$leave->id],'files'=>true]); ?>



<div class="card pt-3 ">
    <div class="form-row">
        <div class="form-group offset-md-1 offset-sm-1 col-md-2 col-sm-2 ">
            <?php echo Form::label('leave_id', 'Leave ID'); ?>

            <?php echo Form::text('leave_id', $leave->leave_code, ['class'=>'form-control','readonly']); ?>

        </div>

        <div class=" form-group col-md-2 col-sm-">
            <?php echo Form::label('input_date', 'Input Date'); ?>

            <?php echo Form::text('input_date', $leave->input_date, ['class'=>'form-control','readonly']); ?>

        </div>

        <div class=" form-group ml-3 col-md-4 col-sm-4 ">
            <?php echo Form::label('type_of_leave', 'Type of Leave'); ?>

            <select id="type_of_leave" name="type_of_leave"
                class="form-control <?php $__errorArgs = ['type_of_leave'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <option value="<?php echo e($leave->type_of_leave); ?>"><?php echo e($leave->type_of_leave); ?></option>
                <option value="Business Trip" <?php if(old('type_of_leave')=='Business Trip' ): ?> selected="selected" <?php endif; ?>>
                    Business Trip</option>
                <option value="Sick Leave" <?php if(old('type_of_leave')=='Sick Leave' ): ?> selected="selected" <?php endif; ?>>
                    Sick Leave</option>
                <option value="Maternity Leave" <?php if(old('type_of_leave')=='Maternity Leave' ): ?> selected="selected"
                    <?php endif; ?>>
                    Maternity Leave</option>
                <option value="Annual Leave" <?php if(old('type_of_leave')=='Annual Leave' ): ?> selected="selected" <?php endif; ?>>
                    Annual Leave</option>
            </select>
        </div>
    </div>

    <div class="form-row">
        <div class="form-group offset-md-1 offset-sm-1 col-md-4 col-sm-4">
            <?php echo Form::label('name', 'Name'); ?>


            <?php echo Form::text('name', Auth::user()->name, ['class'=>'form-control','readonly']); ?>

        </div>

        <div class="form-group ml-3 col-md-4 col-sm-4">
            <?php echo Form::label('description', 'Description'); ?>

            <input type="text" name="description" id="description"
                class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($leave->description); ?>"
                placeholder="Description">
            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class=" invalid-feedback">
                <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="form-row">
        <div class="form-group offset-md-1 offset-sm-1 col-md-4 col-sm-4 ">
            <?php echo Form::label('employee_id', 'Employee ID'); ?>

            <?php echo Form::text('employee_id', Auth::user()->employee->id,
            ['class'=>'form-control','readonly']); ?>

        </div>
        <div class="form-group ml-3 col-md-2 col-sm-2 ">
            <?php echo Form::label('leave_balance', 'Leave Balance'); ?>

            <?php echo Form::number('leave_balance', Auth::user()->employee->leave_balance,
            ['class'=>'form-control','onkeyup'=>'sum();','readonly']); ?>

        </div>
        <div class="form-group ml-3 col-md-2 col-sm-2 ">
            <?php echo Form::label('start_date', 'Start Date'); ?>

            <input type="date" name="start_date" id="start_date" placeholder="start_date" class="form-control 
            <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($leave->start_date); ?>">
            <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class=" invalid-feedback">
                <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="form-row">
        <div class="form-group offset-md-1 offset-sm-1 col-md-4 col-sm-4 ">
            <?php echo Form::label('department', 'Department'); ?>

            <?php echo Form::text('department', Auth::user()->employee->department,
            ['class'=>'form-control','readonly']); ?>

        </div>
        <div class="form-group ml-3 col-md-2 col-sm-2 ">
            <?php echo Form::label('leave_amount', 'Leave Amount'); ?>

            <input type="number" name="leave_amount" id="leave_amount" class="form-control 
            <?php $__errorArgs = ['leave_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($leave->leave_amount); ?>" onkeyup="sum()"
                max="<?php echo e(Auth::user()->employee->leave_balance); ?>">
            <?php $__errorArgs = ['leave_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class=" invalid-feedback">
                <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group ml-3 col-md-2 col-sm-2 ">
            <?php echo Form::label('current_leave', 'Current Leave'); ?>

            <?php echo Form::text('current_leave', Auth::user()->employee->leave_balance - $leave->leave_amount,
            ['class'=>'form-control','readonly']); ?>

        </div>

    </div>

    <div class="form-row">
        <div class="form-group offset-md-1 offset-sm-1 col-md-4 col-sm-4">
            <?php echo Form::label('position', 'Position'); ?>

            <?php echo Form::text('position', Auth::user()->employee->position,
            ['class'=>'form-control','readonly']); ?>

        </div>

        <div class="form-group ml-3 col-md-4 col-sm-4">
            <?php echo Form::label('phone', 'Phone Number'); ?>

            <input type="number" name="phone" id="phone" class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                value="<?php echo e($leave->phone); ?>">
            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class=" invalid-feedback">
                <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        </div>
    </div>

    <div class="form-group offset-md-1 offset-sm-1 mt-3">
        <?php echo Form::submit('Save Changes', ['class'=>'btn btn-primary']); ?>

        <a href="<?php echo e(Route('user.home')); ?>"><button type="button" class="btn btn-secondary">Back</button></a>
    </div>
</div>
<?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Paidleavy\resources\views/user/leave/edit.blade.php ENDPATH**/ ?>