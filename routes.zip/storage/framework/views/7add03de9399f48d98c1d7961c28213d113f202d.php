<header class="header" id="header">
    <div class="header__toggle">
        <i class="bx bx-menu" id="header-toggle"></i>
    </div>

    <div class="header__user">

        <img src="/images/<?php echo e(Auth::user()->employee->path); ?>" alt="profile" class="header__img mr-3" />

        <button class="header__user-data dropdown-toggle" data-toggle="dropdown" aria-haspopup="true"
            aria-expanded="false" id="navbarDropdownMenuLink">
            <span><?php echo e(Auth::user()->employee->name); ?></span>
        </button>

        <div class="dropdown-menu dropdown-menu-right mt-2 user-profile__dropdown">
            <button class="dropdown-item d-flex" type="button" data-toggle="modal" data-target="#showProfile">
                <i class="bx bxs-user-circle bx-sm mr-2"></i>
                My Profile
            </button>
            <button class="dropdown-item d-flex" data-toggle="modal" data-target="#logout">
                <i class="bx bx-log-out bx-sm mr-2"></i>
                Logout
            </button>


        </div>
    </div>
</header>

<div class="l-navbar" id="nav-bar">
    <nav class="nav">
        <div>
            <div class="mb-4 mt-1 d-flex" style="margin-left:-9px;">
                <img src="/assets/img/logo2.png" style="width:98%">
            </div>

            <div class="nav__list">
                <div class="nav__item">
                    <li>
                        <a href="<?php echo e(Route('user.home')); ?>" class="nav__link" title="Dashboard">
                            <i class="bx bx-grid-alt nav__icon"></i>
                            <span class="nav__name">Dashboard</span>
                        </a>
                    </li>
                </div>

                <div class="nav__item">
                    <li>
                        <a href="#cuti-karyawan" class="nav__link" title="Cuti Karyawan" data-toggle="collapse">
                            <i class="bx bx-user nav__icon"></i>
                            <span class="nav__name dropdown-toggle">Employee Leave</span>
                        </a>

                        <ul class="collapse list-unstyled cuti-karyawan__list" id="cuti-karyawan">
                            <li><a href="<?php echo e(Route('user.leave.create')); ?>" class="text-white masterdata__list-item">Leave
                                    Application</a>
                            </li>
                            <li><a href="<?php echo e(Route('user.historyLeave.index')); ?>"
                                    class="text-white masterdata__list-item">Leave History</a>
                            </li>
                        </ul>
                    </li>
                </div>
            </div>
        </div>
        <a href="#" class="nav__link" title="Logout" data-toggle="modal" data-target="#logout">
            <i class="bx bx-log-out nav__icon"></i>
            <span class="nav__name">Log Out</span>
        </a>
    </nav>
</div><?php /**PATH D:\xampp\htdocs\Paidleavy\resources\views/components/userSidebar.blade.php ENDPATH**/ ?>