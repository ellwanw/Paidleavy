

<?php $__env->startSection('content'); ?>
<br>
<h4>Create Employee</h4>
<?php if(session('status')): ?>
<div class="alert alert-danger">
    <?php echo e(session('status')); ?>

</div>
<?php endif; ?>
<?php echo Form::open(['method'=>'POST','action'=>'EmployeeController@store','files'=>true]); ?>

<div class="card pt-3 ">
    <div class="form-group row offset-md-1">
        <?php echo Form::label('employee_id', 'Employee ID :', ['class'=>'col-sm-2 col-form-label']); ?>

        <div class="col-sm-10">

            <input type="text" name="employee_id" id="employee_id" placeholder="Employee ID" class="form-control w-50 
        <?php $__errorArgs = ['employee_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('employee_id')); ?>">

            <?php $__errorArgs = ['employee_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class=" invalid-feedback">
                <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        </div>
    </div>
    <div class="form-group row offset-md-1">
        <?php echo Form::label('name', 'Name :', ['class'=>'col-sm-2 col-form-label']); ?>

        <div class="col-sm-10">
            <input type="text" name="name" id="name" placeholder="Name" class="form-control w-50 
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('name')); ?>">

            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class=" invalid-feedback">
                <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>
    <div class=" form-group row offset-md-1">
        <?php echo Form::label('date_of_entry', 'Date of Entry:', ['class'=>'col-sm-2 col-form-label']); ?>

        <div class="col-sm-10">
            <input type="date" name="date_of_entry" id="date_of_entry" placeholder="Date of Entry" class="form-control w-50 
        <?php $__errorArgs = ['date_of_entry'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('date_of_entry')); ?>">

            <?php $__errorArgs = ['date_of_entry'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class=" invalid-feedback">
                <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>
    <div class="form-group row offset-md-1">
        <?php echo Form::label('position', 'Position :', ['class'=>'col-sm-2 col-form-label']); ?>

        <div class="col-sm-10">
            <select id="position" name="position" class="form-control w-50 <?php $__errorArgs = ['position'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <option value="">----- Choose Position -----</option>
                <?php $__currentLoopData = $positions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $position): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option <?php echo e(old('position') == $position->name ? "selected" : ""); ?> value="<?php echo e($position->name); ?>">
                    <?php echo e($position->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>


            <?php $__errorArgs = ['position'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class=" invalid-feedback">
                <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="form-group row offset-md-1">
        <?php echo Form::label('department', 'Department :', ['class'=>'col-sm-2 col-form-label']); ?>

        <div class="col-sm-10">
            <select id="department" name="department"
                class="form-control w-50 <?php $__errorArgs = ['department'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <option value="">----- Choose Department -----</option>
                <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option <?php echo e(old('department') == $department->name ? "selected" : ""); ?> value="<?php echo e($department->name); ?>">
                    <?php echo e($department->name); ?></option>
                <?php echo e($department->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['department'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class=" invalid-feedback">
                <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>
    <div class="form-group row offset-md-1">
        <?php echo Form::label('status', 'Status :', ['class'=>'col-sm-2 col-form-label ']); ?>

        <div class="col-sm-10">

            <select id="status" name="status" class="form-control w-50 <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <option value="">----- Choose Status -----</option>
                <option value="Regular Worker" <?php if(old('status')=='Regular Worker' ): ?> selected="selected" <?php endif; ?>>Regular
                    Worker</option>
                <option value="Temporary Worker" <?php if(old('status')=='Temporary Worker' ): ?> selected="selected" <?php endif; ?>>
                    Temporary Worker</option>
                <option value="Daily Worker" <?php if(old('status')=='Daily Worker' ): ?> selected="selected" <?php endif; ?>>Daily
                    Worker</option>
            </select>
            <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class=" invalid-feedback">
                <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        </div>
    </div>

    <div class="form-group row offset-md-1">
        <?php echo Form::label('path', 'Image :', ['class'=>'col-sm-2 col-form-label']); ?>

        <div class="col-sm-10">
            <?php echo Form::file('path',['class'=>'form-control-file w-50','accept'=>'image/*','required']); ?>

        </div>
    </div>
    <div class="form-group offset-md-1 offset-sm-1 mt-4">
        <?php echo Form::submit('Create Employee', ['class'=>'btn btn-primary']); ?>

        <a href="<?php echo e(Route('admin.employee.index')); ?>"><button type="button" class="btn btn-secondary ">Back</button></a>

    </div>

</div>
<?php echo Form::close(); ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Paidleavy\resources\views/admin/employee/create.blade.php ENDPATH**/ ?>