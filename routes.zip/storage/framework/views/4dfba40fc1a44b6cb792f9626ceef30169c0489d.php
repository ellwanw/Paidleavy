

<?php $__env->startSection('content'); ?>
<br>
<h4>Edit Employee</h4>
<?php if(session('status')): ?>
<div class="alert alert-danger">
    <?php echo e(session('status')); ?>

</div>
<?php endif; ?>
<?php echo Form::open(['method'=>'PATCH','action'=>['EmployeeController@update',$employee->id],'files'=>true]); ?>

<div class="card pt-3 ">
    <div class="form-group row offset-md-1">
        <?php echo Form::label('employee_id', 'Employee ID :', ['class'=>'col-sm-2 col-form-label']); ?>

        <div class="col-sm-10">
            <?php echo Form::text('employee_id', $employee->employee_id, ['class'=>'form-control w-50'],['placeholder' =>
            'Employee ID']); ?>

        </div>
    </div>
    <div class="form-group row offset-md-1">
        <?php echo Form::label('name', 'Name :', ['class'=>'col-sm-2 col-form-label']); ?>

        <div class="col-sm-10">
            <?php echo Form::text('name', $employee->name, ['class'=>'form-control w-50'],['placeholder' => 'Name']); ?>

        </div>
    </div>
    <div class="form-group row offset-md-1">
        <?php echo Form::label('date_of_entry', 'Date of Entry:', ['class'=>'col-sm-2 col-form-label']); ?>

        <div class="col-sm-10">
            <?php echo Form::text('date_of_entry', $employee->date_of_entry, ['class'=>'form-control w-50'],['placeholder' =>
            'Date Of Entry']); ?>

        </div>
    </div>
    <div class="form-group row offset-md-1">
        <?php echo Form::label('position', 'Position :', ['class'=>'col-sm-2 col-form-label']); ?>

        <div class="col-sm-10">
            <select id="position" name="position" class="form-control w-50">
                <option value="<?php echo e($employee->position); ?>"><?php echo e($employee->position); ?></option>
                <?php $__currentLoopData = $positions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $position): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($position->name); ?>"><?php echo e($position->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>
    <div class="form-group row offset-md-1">
        <?php echo Form::label('department', 'Department :', ['class'=>'col-sm-2 col-form-label']); ?>

        <div class="col-sm-10">
            <select id="department" name="department" class="form-control w-50">
                <option value="<?php echo e($employee->department); ?>"><?php echo e($employee->department); ?></option>
                <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($department->name); ?>"><?php echo e($department->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select> </div>
    </div>
    <div class="form-group row offset-md-1">
        <?php echo Form::label('status', 'Status :', ['class'=>'col-sm-2 col-form-label']); ?>

        <div class="col-sm-10">
            <select id="status" name="status" class="form-control w-50">
                <option value="<?php echo e($employee->status); ?>"><?php echo e($employee->status); ?></option>
                <option value="Regular Worker">Regular Worker</option>
                <option value="Temporary Worker">Temporary Worker</option>
                <option value="Daily Worker">Daily Worker</option>
            </select> </div>
    </div>

    <div class="form-group row offset-md-1">
        <?php echo Form::label('image', 'Image :', ['class'=>'col-sm-2 col-form-label']); ?>

        <div class="col-sm-10">
            <img src="/images/<?php echo e($employee->path); ?>" style="width: 20%">
            <br>
            <?php echo Form::file('path',['class'=>'form-control-file w-50','accept'=>'image/*']); ?>

        </div>
    </div>

    <input type="hidden" name="oldpath" value="<?php echo e($employee->path); ?>">

    <div class="form-group offset-md-1 offset-sm-1 mt-4" style="margin-left:25%;">
        <?php echo Form::submit('Edit', ['class'=>'btn btn-primary']); ?>

    </div>
</div>
<?php echo Form::close(); ?>

<br>
<a href="/admin/employee/<?php echo e($employee->id); ?>" class="text-white"><button type="button"
        class="btn btn-secondary">Back</button></a>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Paidleavy\resources\views/admin/employee/edit.blade.php ENDPATH**/ ?>