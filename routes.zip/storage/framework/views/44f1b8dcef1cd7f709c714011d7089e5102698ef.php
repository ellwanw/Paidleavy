

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<h4 class="mt-5 pt-3 mb-3">Position List</h4>
<?php if(session('status')): ?>
<div class="alert alert-success">
    <?php echo e(session('status')); ?>

</div>
<?php endif; ?>
<a href="<?php echo e(Route('admin.position.create')); ?>"><button type="button" class="btn btn-primary mb-3"> Add Position
        <i class="fab fa-black-tie"></i>
    </button></a>
<table class="table table-striped table-hover text-center table-shadow">
    <thead>
        <tr>
            <th scope="col">No</th>
            <th scope="col">Position ID</th>
            <th scope="col">Name</th>
            <th scope="col">Action</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $positions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $position): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th scope="row"><?php echo e($loop->iteration); ?></th>
            <td><?php echo e($position->position_id); ?></td>
            <td><?php echo e($position->name); ?></td>
            <td>
                <a href="position/<?php echo e($position->id); ?>/edit"><button class="btn btn-warning"><i
                            class="bx bx-edit-alt bx-xs"></i></button></a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<a href="<?php echo e(Route('admin.home')); ?>" class="text-white"><button type="button" class="btn btn-secondary">Back</button></a>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Paidleavy\resources\views/admin/position/index.blade.php ENDPATH**/ ?>