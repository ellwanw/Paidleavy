

<?php $__env->startSection('content'); ?>
<!-- Dashboard User here -->
<h3 class="mt-5 pt-3">User's Dashboard</h3>

<div class="container">
    <div class="row">
        <div class="col-lg-3 col-md-6 col-sm-6">
            <div class="card mt-5 admin-card">
                <div class="card-body card-content">
                    <div>
                        <h1><?php echo e($myLeaves->count()); ?></h1>
                        <h5 class="card-title">Leave History</h5>
                    </div>
                    <i class='bx bx-history'></i>
                </div>

                <div class="card-footer">
                    <a href="<?php echo e(Route('user.historyLeave.index')); ?>" class="card-link">View More</a>
                </div>
            </div>
        </div>

        <div class="col-lg-3 col-md-6 col-sm-6">
            <div class="card mt-5 admin-card">
                <div class="card-body card-content">
                    <div>
                        <h1><?php echo e($leaveRejected->count()); ?></h1>
                        <h5 class="card-title">Rejected Leave</h5>
                    </div>
                    <i class='bx bxs-x-circle'></i>
                </div>

                <div class="card-footer">
                    <a href="<?php echo e(Route('user.rejectedLeave.index')); ?>" class="card-link">View More</a>
                </div>
            </div>
        </div>

        <div class="col-lg-3 col-md-6 col-sm-6">
            <div class="card mt-5 admin-card">
                <div class="card-body card-content">
                    <div>
                        <h1><?php echo e($leaveApproved->count()); ?></h1>
                        <h5 class="card-title">Approved Leave</h5>
                    </div>
                    <i class='bx bxs-check-circle'></i>
                </div>

                <div class="card-footer">
                    <a href="<?php echo e(Route('user.approvedLeave.index')); ?>" class="card-link">View More</a>
                </div>
            </div>
        </div>

        <div class="col-lg-3 col-md-6 col-sm-6">
            <div class="card mt-5 admin-card">
                <div class="card-body card-content" style="padding-top:2rem">
                    <div>
                        <h5 class="card-title">My</h5>
                        <h5 class="card-title"> Profile</h5>
                    </div>
                    <i class='bx bxs-user-circle'></i>
                </div>

                <div class="card-footer">
                    <a href="#" class="card-link" data-toggle="modal" data-target="#showProfile">View More</a>
                </div>
            </div>
        </div>
    </div>
</div>
</div>

<br>
<div class="jumbotron ">

    <?php if(session('status')): ?>
    <div class="alert alert-success">
        <?php echo e(session('status')); ?>

    </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
    <div class="alert alert-danger">
        <?php echo e(session('error')); ?>

    </div>
    <?php endif; ?>
    <?php if($waitingLeave->count() == 1): ?>
    <?php $__currentLoopData = $waitingLeave; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="leaveStatus text-dark">
        <div class="card bg-light mb-3" style="max-width: 18rem;">
            <div class="card-header ">
                <h4>Leave Status</h4>
            </div>
            <div class="card-body">
                <h6 class="card-text">
                    <ul class="list-unstyled">
                        <li class="mb-2">From : <?php echo e(date_format(new DateTime($wl->start_date), 'd-m-Y')); ?></li>
                        <li class="mb-2">Till : <?php echo e(date_format(new DateTime($wl->end_date), 'd-m-Y')); ?></li>
                        <li class="mb-2">Description : <?php echo e($wl->description); ?></li>
                        <li class="mb-2">Leave Amount : <?php echo e($wl->leave_amount); ?></li>
                        <?php if($wl->status == '0'): ?>
                        <li class="mb-2">Leave Status : Waiting</li>
                        <?php endif; ?>
                        <br>
                        <a href="leave/<?php echo e($wl->id); ?>/edit"><button type="button" class="btn btn-primary">Edit</button></a>

                        <a href="#" data-id="<?php echo e($wl->id); ?>" id="post_title<?php echo e($wl->id); ?>"
                            class="btn btn-danger swal-confirm">
                            <form action="leave/<?php echo e($wl->id); ?>" class="d-inline" id="delete<?php echo e($wl->id); ?>" method="POST">
                                <?php echo method_field('delete'); ?>
                                <?php echo csrf_field(); ?>
                            </form>
                            Cancel Application
                        </a>

                        



                    </ul>
                </h6>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
            <h1 class="display-4">Welcome, <?php echo e(Auth::user()->employee->name); ?></h1>
            <p class="lead">
                Currently there is no new request for leave</p>
            <hr class="my-4">
            <a href="<?php echo e(Route('user.leave.create')); ?>"><button type="button" class="btn btn-primary">Apply for
                    leave</button></a>
            <p class="lead">
            </p>
            <?php endif; ?>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Paidleavy\resources\views/user/home.blade.php ENDPATH**/ ?>