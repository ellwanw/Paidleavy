

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<h4 class="mt-5 pt-3 mb-3">Employee Data List</h4>
<?php if(session('status')): ?>
<div class="alert alert-success">
    <?php echo e(session('status')); ?>

</div>
<?php endif; ?>
<a href="<?php echo e(Route('admin.employee.create')); ?>"><button type="button" class="btn btn-primary mb-3"> Add Employee
        <i class="fa fa-user-plus ml-1" aria-hidden="true"></i>
    </button></a>

<form class="form-inline" action="/admin/employee/cari" method="GET">

    <input type="text" name="cari" placeholder="Search for employee name.." class="form-control">
    <button type="submit" class="btn btn-primary ml-2"><i class="fa fa-search"></i></button>
    <a href="<?php echo e(Route('admin.employee.index')); ?>"><button type="button" class="btn btn-success text-white ml-5">Show
            All</button></a>
</form>

<table class="table table-striped table-hover text-center table-shadow mt-4">
    <thead>
        <tr>
            <th scope="col">No</th>
            <th scope="col">Employee ID</th>
            <th scope="col">Name</th>
            <th scope="col">Department</th>
            <th scope="col">Position</th>
            <th scope="col">Status</th>
            <th scope="col">Leave Balance</th>
            <th scope="col">Action</th>
        </tr>
    </thead>
    <tbody>
        <?php $i = $employees->firstItem();?>
        <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th scope="row"><?php echo e($i); ?></th>
            <td><?php echo e($employee->employee_id); ?></td>
            <td><?php echo e($employee->name); ?></td>
            <td><?php echo e($employee->department); ?></td>
            <td><?php echo e($employee->position); ?></td>
            <td><?php echo e($employee->status); ?></td>
            <td><?php echo e($employee->leave_balance); ?></td>
            <td>
                <a href="/admin/employee/<?php echo e($employee->id); ?>" class="text-white"><button type="button"
                        class="btn btn-primary" type="button">
                        <i class="bx bx-search-alt bx-xs"></i>
                    </button></a>
            </td>
        </tr>
        <?php $i++; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<div class="d-flex justify-content-center">
    <?php echo e($employees->links()); ?>

</div>
<a href="<?php echo e(Route('admin.home')); ?>" class="text-white"><button type="button" class="btn btn-secondary">Back</button></a>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Paidleavy\resources\views/admin/employee/index.blade.php ENDPATH**/ ?>