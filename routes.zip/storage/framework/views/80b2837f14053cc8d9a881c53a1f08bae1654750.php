

<?php $__env->startSection('content'); ?>
<h4 class="mt-5 pt-3 mb-3">Employee Data Detail</h4>
<div class="foto-detailkaryawan" style="position: absolute; left:65%;">
    <img src="/images/<?php echo e($employee->path); ?>" style="width: 40%;">
</div>
<table class="table table-striped table-hover table-karyawan w-75 ml-5">
    <tr>
        <th scope="col">Employee ID</th>
        <td><?php echo e($employee->employee_id); ?></td>
    </tr>
    <tr>
        <th scope="col">Name</th>
        <td><?php echo e($employee->name); ?></td>
    </tr>
    <tr>
        <th scope="col">Status</th>
        <td><?php echo e($employee->status); ?></td>
    </tr>
    <tr>
        <th scope="col">Date of Entry</th>
        <td><?php echo e(date_format(new DateTime($employee->date_of_entry), 'd-m-Y')); ?></td>
    </tr>
    <tr>
        <th scope="col">Department</th>
        <td><?php echo e($employee->department); ?></td>
    </tr>
    <tr>
        <th scope="col">Position</th>
        <td><?php echo e($employee->position); ?></td>
    </tr>
    <tr>
        <th scope="col">Leave Balance</th>
        <td><?php echo e($employee->leave_balance); ?></td>
    </tr>
</table>
<br>


<a href="<?php echo e(Route('admin.employee.index')); ?>" class="text-white ml-5"><button type="button"
        class="btn btn-secondary">Back</button></a>

<a href="#" data-id="<?php echo e($employee->id); ?>" id="post_title<?php echo e($employee->id); ?>" class="btn btn-danger swal-confirm">
    <form action="<?php echo e($employee->id); ?>" class="d-inline" id="delete<?php echo e($employee->id); ?>" method="POST">
        <?php echo method_field('delete'); ?>
        <?php echo csrf_field(); ?>
    </form>
    Delete
</a>

<a href="<?php echo e($employee->id); ?>/edit"><button class="btn btn-warning text-white">Edit</button></a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Paidleavy\resources\views/admin/employee/show.blade.php ENDPATH**/ ?>